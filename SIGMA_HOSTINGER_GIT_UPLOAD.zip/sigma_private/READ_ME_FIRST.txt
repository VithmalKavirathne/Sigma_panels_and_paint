This "sigma_private" folder must be placed ONE LEVEL ABOVE public_html
on the server (next to public_html, not inside it) and must NEVER be
committed to Git. It holds the real database credentials that
public_html/includes/config.php loads.
