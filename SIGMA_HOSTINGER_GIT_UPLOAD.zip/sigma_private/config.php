<?php
// Sigma Panels & Paint - PRIVATE production configuration.
// =======================================================================
// NEVER commit this file to Git. It must live OUTSIDE public_html:
//     domains/your-domain/sigma_private/config.php
// (one level above the public_html web root).
// =======================================================================

define('DB_HOST', 'localhost');            // Hostinger MySQL host (usually 'localhost')
define('DB_PORT', '3306');                 // Hostinger MySQL port (usually 3306)
define('DB_NAME', 'REPLACE_DB_NAME');      // e.g. u123456789_sigma
define('DB_USER', 'REPLACE_DB_USER');      // e.g. u123456789_sigma
define('DB_PASS', 'REPLACE_DB_PASSWORD');  // your real DB password

// Final domain, https, no trailing slash. e.g. https://sigmapanelsandpaint.com.au
define('BASE_URL', 'https://REPLACE-YOUR-DOMAIN');
